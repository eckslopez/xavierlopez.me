---
layout: single
title:  "Virtualization - Network"
date:   2023-12-02 10:59:00 +0000
categories: virtualization,networking
---
- Network Virtualization
    - Virtual Switches
    - Virtual Firewalls
    - Virtual NICs
      - These map back to physical network adapters.
