---
layout: single
title:  "Host Storage Management"
date:   2023-11-29 10:44:00 +0000
categories: linux
---
> **Linux Modules**: Code segments that can be dynamically loaded and unloaded into the kernel. They can be removed when they are no longer needed. Modules extend the functionality of the kernel without requiring a reboot. They can configured as built-in or loadable. 
- List modules in alphabetical order: `lsmod | sort -d | column -t | less`

> **Device Drivers**: a piece of software that allows the operating system to communicate with a specific hardware device. It acts as an interface between the hardware device and the rest of the operating system, facilitating the exchange of data and commands.
- List device drivers: `lsmod`

### Physical Storage
- List disk and partition tables: `fdisk -l`
- List mounted filesystems: `findmnt`
- Show the definitions for partitions, along with a description of how it's mounted: `cat /etc/fstab`
- Discover what files are open and who's using it: `lsof`

### Create a partition to make a newly added disk usable:
  1. First, go add the disk using hypervisor GUI or CLI.
  2. Choose the disk you want to partition: `fdisk /dev/<disk-name>`
  4. Follow the prompts.
  5. Create a file system on the disk: `sudo mkfs -t ext3 /dev/<disk-partition-name>`
  7. Create a mount point and mount it to the partition, if you're not going to use LVM1 to manage it: `sudo mkdir /mnt/test && mount /dev/<disk-partition-name> /mnt/test`
  11. View partitions: `sudo cat /proc/partitions`

- List all mounted filesystems. See Master Linux Storage Management with LVM Chapter 3 'Command Line Tools' for the procedure on LVM.
